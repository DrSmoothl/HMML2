<template>
  <router-view />
</template>

<script setup lang="ts">
// 设置布局组件，用于包含设置相关的子页面
</script>
