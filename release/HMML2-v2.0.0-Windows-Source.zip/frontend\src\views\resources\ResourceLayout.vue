<template>
  <router-view />
</template>

<script setup lang="ts">
// 资源管理布局组件
</script>
