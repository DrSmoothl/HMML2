<!-- 已迁移为全局模态 TokenGateModal，保留空文件避免潜在引用报错，可后续删除 -->
<template></template>
